# -*- coding: utf-8 -*-
"""
Created on Wed Oct 11 13:31:43 2017

@author: Jay Monpara,
Student ID - 10360474
"""
# invoke dealership program

from Car_CA import Dealership # importing Dealership class

Aungier_dealer = Dealership() # creating AUngier dealer, an object.
print Aungier_dealer.create_stock() # asisging stock to the dealer
Aungier_dealer.process_options() # Invoke dealership process with available options.33






